import tkinter as tk
import json
from tkinter import Frame,Label,Entry,Button,Radiobutton,ttk,VERTICAL,YES,BOTH,END,Tk,W,StringVar,messagebox
from Kunjungan import *
class FrmKunjungan:
    
    def __init__(self, parent, title):
        self.parent = parent       
        self.parent.geometry("650x450")
        self.parent.title(title)
        self.parent.protocol("WM_DELETE_WINDOW", self.onKeluar)
        self.ditemukan = None
        self.aturKomponen()
        self.onReload()
        
    def aturKomponen(self):
        mainFrame = Frame(self.parent, bd=10)
        mainFrame.pack(fill=BOTH, expand=YES)
        Label(mainFrame, text='Kode Kunjungan:').grid(row=0, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='Kode Pasien:').grid(row=1, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='Kode Dokter:').grid(row=2, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='Jadwal:').grid(row=3, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='Keluhan:').grid(row=4, column=0,
            sticky=W, padx=5, pady=5)
        # Textbox
        self.txtKodeKunjungan = Entry(mainFrame) 
        self.txtKodeKunjungan.grid(row=0, column=1, padx=5, pady=5)
        self.txtKodeKunjungan.bind("<Return>",self.onCari) # menambahkan event Enter key
        # Textbox
        self.txtKodePasien = Entry(mainFrame) 
        self.txtKodePasien.grid(row=1, column=1, padx=5, pady=5)
        # Textbox
        self.txtKodeDokter = Entry(mainFrame) 
        self.txtKodeDokter.grid(row=2, column=1, padx=5, pady=5)
        # Textbox
        self.txtTglKunjungan = Entry(mainFrame) 
        self.txtTglKunjungan.grid(row=3, column=1, padx=5, pady=5)
        # Textbox
        self.txtKeluhan = Entry(mainFrame) 
        self.txtKeluhan.grid(row=4, column=1, padx=5, pady=5)
        # Button
        self.btnSimpan = Button(mainFrame, text='Simpan', command=self.onSimpan, width=10)
        self.btnSimpan.grid(row=0, column=3, padx=5, pady=5)
        self.btnClear = Button(mainFrame, text='Clear', command=self.onClear, width=10)
        self.btnClear.grid(row=1, column=3, padx=5, pady=5)
        self.btnHapus = Button(mainFrame, text='Hapus', command=self.onDelete, width=10)
        self.btnHapus.grid(row=2, column=3, padx=5, pady=5)
        # define columns
        columns = ('kodeKunjungan','kodePasien','kodeDokter','tglKunjungan','keluhan')
        self.tree = ttk.Treeview(mainFrame, columns=columns, show='headings')
        # define headings
        self.tree.heading('kodeKunjungan', text='Kode')
        self.tree.column('kodeKunjungan', width="80")
        self.tree.heading('kodePasien', text='Kode Pasien')
        self.tree.column('kodePasien', width="80")
        self.tree.heading('kodeDokter', text='Kode Dokter')
        self.tree.column('kodeDokter', width="80")
        self.tree.heading('tglKunjungan', text='Jadwal Kunjungan')
        self.tree.column('tglKunjungan', width="115")
        self.tree.heading('keluhan', text='Keluhan')
        self.tree.column('keluhan', width="150")
        # set tree position
        self.tree.place(x=0, y=200)
        
    def onClear(self, event=None):
        self.txtKodeKunjungan.delete(0,END)
        self.txtKodeKunjungan.insert(END,"")
        self.txtKodePasien.delete(0,END)
        self.txtKodePasien.insert(END,"")
        self.txtKodeDokter.delete(0,END)
        self.txtKodeDokter.insert(END,"")
        self.txtTglKunjungan.delete(0,END)
        self.txtTglKunjungan.insert(END,"")
        self.txtKeluhan.delete(0,END)
        self.txtKeluhan.insert(END,"")
        self.btnSimpan.config(text="Simpan")
        self.onReload()
        self.ditemukan = False
        
    def onReload(self, event=None):
        # get data kunjungan
        obj = Kunjungan()
        result = obj.get_all()
        parsed_data = json.loads(result)
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        for i, d in enumerate(parsed_data):
            self.tree.insert("", i, text="Item {}".format(i), values=(d["kodeKunjungan"],d["kodePasien"],d["kodeDokter"],d["tglKunjungan"],d["keluhan"]))
    def onCari(self, event=None):
        kodeKunjungan = self.txtKodeKunjungan.get()
        obj = Kunjungan()
        a = obj.get_by_kodeKunjungan(kodeKunjungan)
        if(len(a)>0):
            self.TampilkanData()
            self.ditemukan = True
        else:
            self.ditemukan = False
            messagebox.showinfo("showinfo", "Data Tidak Ditemukan")
    def TampilkanData(self, event=None):
        kodeKunjungan = self.txtKodeKunjungan.get()
        obj = Kunjungan()
        res = obj.get_by_kodeKunjungan(kodeKunjungan)
        self.txtKodeKunjungan.delete(0,END)
        self.txtKodeKunjungan.insert(END,obj.kodeKunjungan)
        self.txtKodePasien.delete(0,END)
        self.txtKodePasien.insert(END,obj.kodePasien)
        self.txtKodeDokter.delete(0,END)
        self.txtKodeDokter.insert(END,obj.kodeDokter)
        self.txtTglKunjungan.delete(0,END)
        self.txtTglKunjungan.insert(END,obj.tglKunjungan)
        self.txtKeluhan.delete(0,END)
        self.txtKeluhan.insert(END,obj.keluhan)
        self.btnSimpan.config(text="Update")
                 
    def onSimpan(self, event=None):
        # get the data from input
        kodeKunjungan = self.txtKodeKunjungan.get()
        kodePasien = self.txtKodePasien.get()
        kodeDokter = self.txtKodeDokter.get()
        tglKunjungan = self.txtTglKunjungan.get()
        keluhan = self.txtKeluhan.get()
        # create new Object
        obj = Kunjungan()
        obj.kodeKunjungan = kodeKunjungan
        obj.kodePasien = kodePasien
        obj.kodeDokter = kodeDokter
        obj.tglKunjungan = tglKunjungan
        obj.keluhan = keluhan
        if(self.ditemukan==False):
            # save the record
            res = obj.simpan()
        else:
            # update the record
            res = obj.update_by_kodeKunjungan(kodeKunjungan)
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        #clear the form input
        self.onClear()
    def onDelete(self, event=None):
        kodeKunjungan = self.txtKodeKunjungan.get()
        obj = Kunjungan()
        obj.kodeKunjungan = kodeKunjungan
        if(self.ditemukan==True):
            res = obj.delete_by_kodeKunjungan(kodeKunjungan)
        else:
            messagebox.showinfo("showinfo", "Data harus ditemukan dulu sebelum dihapus")
            
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        
        self.onClear()
            
    def onKeluar(self, event=None):
        # memberikan perintah menutup aplikasi
        self.parent.destroy()
if __name__ == '__main__':
    root2 = tk.Tk()
    aplikasi = FrmKunjungan(root2, "Aplikasi Data Kunjungan")
    root2.mainloop()