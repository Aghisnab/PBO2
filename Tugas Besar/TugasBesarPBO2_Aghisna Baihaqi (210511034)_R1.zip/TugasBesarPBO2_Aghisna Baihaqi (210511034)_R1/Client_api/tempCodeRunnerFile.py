def onDelete(self, event=None):
        kodeResep = self.txtKodeResep.get()
        obj = Resep()
        obj.kodeResep = kodeResep
        if(self.ditemukan==True):
            res = obj.delete_by_kodeResep(kodeResep)
        else:
            messagebox.showinfo("showinfo", "Data harus ditemukan dulu sebelum dihapus")
            
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        
        self.onClear()