import tkinter as tk
import json
from tkinter import Frame,Label,Entry,Button,Radiobutton,ttk,VERTICAL,YES,BOTH,END,Tk,W,StringVar,messagebox
from Pasien import *
class FrmPasien:
    
    def __init__(self, parent, title):
        self.parent = parent       
        self.parent.geometry("450x450")
        self.parent.title(title)
        self.parent.protocol("WM_DELETE_WINDOW", self.onKeluar)
        self.ditemukan = None
        self.aturKomponen()
        self.onReload()
        
    def aturKomponen(self):
        mainFrame = Frame(self.parent, bd=10)
        mainFrame.pack(fill=BOTH, expand=YES)
        Label(mainFrame, text='Kode Pasien:').grid(row=0, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='Nama Pasien:').grid(row=1, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='Jenis Kelamin:').grid(row=2, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='Tanggal Lahir:').grid(row=3, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='Kontak:').grid(row=4, column=0,
            sticky=W, padx=5, pady=5)
        # Textbox
        self.txtKodePasien = Entry(mainFrame) 
        self.txtKodePasien.grid(row=0, column=1, padx=5, pady=5)
        self.txtKodePasien.bind("<Return>",self.onCari) # menambahkan event Enter key
        # Textbox
        self.txtNamaPasien = Entry(mainFrame) 
        self.txtNamaPasien.grid(row=1, column=1, padx=5, pady=5)
        # Textbox
        self.txtTglLahir = Entry(mainFrame) 
        self.txtTglLahir.grid(row=3, column=1, padx=5, pady=5)
        # Combo Box
        self.txtJk = StringVar()
        Cbo_jk = ttk.Combobox(mainFrame, width = 17, textvariable = self.txtJk) 
        Cbo_jk.grid(row=2, column=1, padx=5, pady=5)
        # Adding jk combobox drop down list
        Cbo_jk['values'] = ('L','P')
        Cbo_jk.current()
        # Textbox
        self.txtKontak = Entry(mainFrame) 
        self.txtKontak.grid(row=4, column=1, padx=5, pady=5)
        # Button
        self.btnSimpan = Button(mainFrame, text='Simpan', command=self.onSimpan, width=10)
        self.btnSimpan.grid(row=0, column=3, padx=5, pady=5)
        self.btnClear = Button(mainFrame, text='Clear', command=self.onClear, width=10)
        self.btnClear.grid(row=1, column=3, padx=5, pady=5)
        self.btnHapus = Button(mainFrame, text='Hapus', command=self.onDelete, width=10)
        self.btnHapus.grid(row=2, column=3, padx=5, pady=5)
        # define columns
        columns = ('kodePasien','namaPasien','jk','tglLahir','kontak')
        self.tree = ttk.Treeview(mainFrame, columns=columns, show='headings')
        # define headings
        self.tree.heading('kodePasien', text='Kode Pasien')
        self.tree.column('kodePasien', width="90")
        self.tree.heading('namaPasien', text='Nama Pasien')
        self.tree.column('namaPasien', width="110")
        self.tree.heading('jk', text='JK')
        self.tree.column('jk', width="50")
        self.tree.heading('tglLahir', text='Tanggal Lahir')
        self.tree.column('tglLahir', width="90")
        self.tree.heading('kontak', text='Kontak')
        self.tree.column('kontak', width="90")
        # set tree position
        self.tree.place(x=0, y=200)
        
    def onClear(self, event=None):
        self.txtKodePasien.delete(0,END)
        self.txtKodePasien.insert(END,"")
        self.txtNamaPasien.delete(0,END)
        self.txtNamaPasien.insert(END,"")
        self.txtJk.set("")
        self.txtTglLahir.delete(0,END)
        self.txtTglLahir.insert(END,"")
        self.txtKontak.delete(0,END)
        self.txtKontak.insert(END,"")
        self.btnSimpan.config(text="Simpan")
        self.onReload()
        self.ditemukan = False
        
    def onReload(self, event=None):
        # get data pasien
        obj = Pasien()
        result = obj.get_all()
        parsed_data = json.loads(result)
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        for i, d in enumerate(parsed_data):
            self.tree.insert("", i, text="Item {}".format(i), values=(d["kodePasien"],d["namaPasien"],d["jk"],d["tglLahir"],d["kontak"]))
    def onCari(self, event=None):
        kodePasien = self.txtKodePasien.get()
        obj = Pasien()
        a = obj.get_by_kodePasien(kodePasien)
        if(len(a)>0):
            self.TampilkanData()
            self.ditemukan = True
        else:
            self.ditemukan = False
            messagebox.showinfo("showinfo", "Data Tidak Ditemukan")
    def TampilkanData(self, event=None):
        kodePasien = self.txtKodePasien.get()
        obj = Pasien()
        res = obj.get_by_kodePasien(kodePasien)
        self.txtKodePasien.delete(0,END)
        self.txtKodePasien.insert(END,obj.kodePasien)
        self.txtNamaPasien.delete(0,END)
        self.txtNamaPasien.insert(END,obj.namaPasien)
        self.txtJk.set(obj.jk)
        self.txtTglLahir.delete(0,END)
        self.txtTglLahir.insert(END,obj.tglLahir)
        self.txtKontak.delete(0,END)
        self.txtKontak.insert(END,obj.kontak)
        self.btnSimpan.config(text="Update")
                 
    def onSimpan(self, event=None):
        # get the data from input
        kodePasien = self.txtKodePasien.get()
        namaPasien = self.txtNamaPasien.get()
        jk = self.txtJk.get()
        tglLahir = self.txtTglLahir.get()
        kontak = self.txtKontak.get()
        # create new Object
        obj = Pasien()
        obj.kodePasien = kodePasien
        obj.namaPasien = namaPasien
        obj.jk = jk
        obj.tglLahir = tglLahir
        obj.kontak = kontak
        if(self.ditemukan==False):
            # save the record
            res = obj.simpan()
        else:
            # update the record
            res = obj.update_by_kodePasien(kodePasien)
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        #clear the form input
        self.onClear()
    def onDelete(self, event=None):
        kodePasien = self.txtKodePasien.get()
        obj = Pasien()
        obj.kodePasien = kodePasien
        if(self.ditemukan==True):
            res = obj.delete_by_kodePasien(kodePasien)
        else:
            messagebox.showinfo("showinfo", "Data harus ditemukan dulu sebelum dihapus")
            
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        
        self.onClear()
            
    def onKeluar(self, event=None):
        # memberikan perintah menutup aplikasi
        self.parent.destroy()
if __name__ == '__main__':
    root2 = tk.Tk()
    aplikasi = FrmPasien(root2, "Aplikasi Data Pasien")
    root2.mainloop()