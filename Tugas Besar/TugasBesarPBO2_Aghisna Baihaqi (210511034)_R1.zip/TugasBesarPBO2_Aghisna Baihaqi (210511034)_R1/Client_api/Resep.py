import requests
import json
class Resep:
    def __init__(self):
        self.__id=None
        self.__kodeResep = None
        self.__kodeKunjungan = None
        self.__obat = None
        self.__dosis = None
        self.__instruksi = None
        self.__url = "http://f0832659.xsph.ru/apprawatjalan/resep_api.php"
                    
    @property
    def id(self):
        return self.__id
    @property
    def kodeResep(self):
        return self.__kodeResep
        
    @kodeResep.setter
    def kodeResep(self, value):
        self.__kodeResep = value
    @property
    def kodeKunjungan(self):
        return self.__kodeKunjungan
        
    @kodeKunjungan.setter
    def kodeKunjungan(self, value):
        self.__kodeKunjungan = value
    @property
    def obat(self):
        return self.__obat
        
    @obat.setter
    def obat(self, value):
        self.__obat = value
    @property
    def dosis(self):
        return self.__dosis
        
    @dosis.setter
    def dosis(self, value):
        self.__dosis = value
    @property
    def instruksi(self):
        return self.__instruksi
        
    @instruksi.setter
    def instruksi(self, value):
        self.__instruksi = value
    def get_all(self):
        payload ={}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(self.__url, json=payload, headers=headers)
        return response.text
    def get_by_kodeResep(self, kodeResep):
        url = self.__url+"?kodeResep="+kodeResep
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, json=payload, headers=headers)
        data = json.loads(response.text)
        for item in data:
            self.__id = item['idResep']
            self.__kodeResep = item['kodeResep']
            self.__kodeKunjungan = item['kodeKunjungan']
            self.__obat = item['obat']
            self.__dosis = item['dosis']
            self.__instruksi = item['instruksi']
        return data
    def simpan(self):
        payload = {
            "kodeResep":self.__kodeResep,
            "kodeKunjungan":self.__kodeKunjungan,
            "obat":self.__obat,
            "dosis":self.__dosis,
            "instruksi":self.__instruksi
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.post(self.__url, data=payload, headers=headers)
        return response.text
    def update_by_kodeResep(self, kodeResep):
        url = self.__url+"?kodeResep="+kodeResep
        payload = {
            "kodeResep":self.__kodeResep,
            "kodeKunjungan":self.__kodeKunjungan,
            "obat":self.__obat,
            "dosis":self.__dosis,
            "instruksi":self.__instruksi
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.put(url, data=payload, headers=headers)
        return response.text
    def delete_by_kodeResep(self,kodeResep):
        url = self.__url+"?kodeResep="+kodeResep
        headers = {'Content-Type': 'application/json'}
        payload={}
        response = requests.delete(url, json=payload, headers=headers)
        return response.text
