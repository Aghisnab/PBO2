import tkinter as tk
import json
from tkinter import Frame,Label,Entry,Button,Radiobutton,ttk,VERTICAL,YES,BOTH,END,Tk,W,StringVar,messagebox
from Resep import *
class FrmResep:
    
    def __init__(self, parent, title):
        self.parent = parent       
        self.parent.geometry("450x450")
        self.parent.title(title)
        self.parent.protocol("WM_DELETE_WINDOW", self.onKeluar)
        self.ditemukan = None
        self.aturKomponen()
        self.onReload()
        
    def aturKomponen(self):
        mainFrame = Frame(self.parent, bd=10)
        mainFrame.pack(fill=BOTH, expand=YES)
        Label(mainFrame, text='Kode Resep:').grid(row=0, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='Kode Kunjungan:').grid(row=1, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='Obat:').grid(row=2, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='Dosis:').grid(row=3, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='Instruksi:').grid(row=4, column=0,
            sticky=W, padx=5, pady=5)
        # Textbox
        self.txtKodeResep = Entry(mainFrame) 
        self.txtKodeResep.grid(row=0, column=1, padx=5, pady=5)
        self.txtKodeResep.bind("<Return>",self.onCari) # menambahkan event Enter key
        # Textbox
        self.txtKodeKunjungan = Entry(mainFrame) 
        self.txtKodeKunjungan.grid(row=1, column=1, padx=5, pady=5)
        # Textbox
        self.txtObat = Entry(mainFrame) 
        self.txtObat.grid(row=2, column=1, padx=5, pady=5)
        # Textbox
        self.txtDosis = Entry(mainFrame) 
        self.txtDosis.grid(row=3, column=1, padx=5, pady=5)
        # Combo Box
        self.txtInstruksi = StringVar()
        Cbo_instruksi = ttk.Combobox(mainFrame, width = 17, textvariable = self.txtInstruksi) 
        Cbo_instruksi.grid(row=4, column=1, padx=5, pady=5)
        # Adding instruksi combobox drop down list
        Cbo_instruksi['values'] = ('Sesudah Makan','Sebelum Makan','Dioleskan','Diteteskan')
        Cbo_instruksi.current()
        # Button
        self.btnSimpan = Button(mainFrame, text='Simpan', command=self.onSimpan, width=10)
        self.btnSimpan.grid(row=0, column=3, padx=5, pady=5)
        self.btnClear = Button(mainFrame, text='Clear', command=self.onClear, width=10)
        self.btnClear.grid(row=1, column=3, padx=5, pady=5)
        self.btnHapus = Button(mainFrame, text='Hapus', command=self.onDelete, width=10)
        self.btnHapus.grid(row=2, column=3, padx=5, pady=5)
        # define columns
        columns = ('kodeResep','kodeKunjungan','obat','dosis','instruksi')
        self.tree = ttk.Treeview(mainFrame, columns=columns, show='headings')
        # define headings
        self.tree.heading('kodeResep', text='Kode')
        self.tree.column('kodeResep', width="80")
        self.tree.heading('kodeKunjungan', text='Kode Kunjungan')
        self.tree.column('kodeKunjungan', width="100")
        self.tree.heading('obat', text='Obat')
        self.tree.column('obat', width="100")
        self.tree.heading('dosis', text='Dosis')
        self.tree.column('dosis', width="90")
        self.tree.heading('instruksi', text='Instruksi')
        self.tree.column('instruksi', width="120")
        # set tree position
        self.tree.place(x=0, y=200)
        
    def onClear(self, event=None):
        self.txtKodeResep.delete(0,END)
        self.txtKodeResep.insert(END,"")
        self.txtKodeKunjungan.delete(0,END)
        self.txtKodeKunjungan.insert(END,"")
        self.txtObat.delete(0,END)
        self.txtObat.insert(END,"")
        self.txtDosis.delete(0,END)
        self.txtDosis.insert(END,"")
        self.txtInstruksi.set("")
        self.btnSimpan.config(text="Simpan")
        self.onReload()
        self.ditemukan = False
        
    def onReload(self, event=None):
        # get data resep
        obj = Resep()
        result = obj.get_all()
        parsed_data = json.loads(result)
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        for i, d in enumerate(parsed_data):
            self.tree.insert("", i, text="Item {}".format(i), values=(d["kodeResep"],d["kodeKunjungan"],d["obat"],d["dosis"],d["instruksi"]))
    def onCari(self, event=None):
        kodeResep = self.txtKodeResep.get()
        obj = Resep()
        a = obj.get_by_kodeResep(kodeResep)
        if(len(a)>0):
            self.TampilkanData()
            self.ditemukan = True
        else:
            self.ditemukan = False
            messagebox.showinfo("showinfo", "Data Tidak Ditemukan")
    def TampilkanData(self, event=None):
        kodeResep = self.txtKodeResep.get()
        obj = Resep()
        res = obj.get_by_kodeResep(kodeResep)
        self.txtKodeResep.delete(0,END)
        self.txtKodeResep.insert(END,obj.kodeResep)
        self.txtKodeKunjungan.delete(0,END)
        self.txtKodeKunjungan.insert(END,obj.kodeKunjungan)
        self.txtObat.delete(0,END)
        self.txtObat.insert(END,obj.obat)
        self.txtDosis.delete(0,END)
        self.txtDosis.insert(END,obj.dosis)
        self.txtInstruksi.set(obj.instruksi)
        self.btnSimpan.config(text="Update")
                 
    def onSimpan(self, event=None):
        # get the data from input
        kodeResep = self.txtKodeResep.get()
        kodeKunjungan = self.txtKodeKunjungan.get()
        obat = self.txtObat.get()
        dosis = self.txtDosis.get()
        instruksi = self.txtInstruksi.get()
        # create new Object
        obj = Resep()
        obj.kodeResep = kodeResep
        obj.kodeKunjungan = kodeKunjungan
        obj.obat = obat
        obj.dosis = dosis
        obj.instruksi = instruksi
        if(self.ditemukan==False):
            # save the record
            res = obj.simpan()
        else:
            # update the record
            res = obj.update_by_kodeResep(kodeResep)
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        #clear the form input
        self.onClear()
    def onDelete(self, event=None):
        kodeResep = self.txtKodeResep.get()
        obj = Resep()
        obj.kodeResep = kodeResep
        if(self.ditemukan==True):
            res = obj.delete_by_kodeResep(kodeResep)
        else:
            messagebox.showinfo("showinfo", "Data harus ditemukan dulu sebelum dihapus")
            
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        
        self.onClear()
            
    def onKeluar(self, event=None):
        # memberikan perintah menutup aplikasi
        self.parent.destroy()
if __name__ == '__main__':
    root2 = tk.Tk()
    aplikasi = FrmResep(root2, "Aplikasi Data Resep")
    root2.mainloop()