import requests
import json
class Dokter:
    def __init__(self):
        self.__id=None
        self.__kodeDokter = None
        self.__nama = None
        self.__spesialis = None
        self.__kontakDokter = None
        self.__url = "http://f0832659.xsph.ru/apprawatjalan/dokter_api.php"
                    
    @property
    def id(self):
        return self.__id
    @property
    def kodeDokter(self):
        return self.__kodeDokter
        
    @kodeDokter.setter
    def kodeDokter(self, value):
        self.__kodeDokter = value
    @property
    def nama(self):
        return self.__nama
        
    @nama.setter
    def nama(self, value):
        self.__nama = value
    @property
    def spesialis(self):
        return self.__spesialis
        
    @spesialis.setter
    def spesialis(self, value):
        self.__spesialis = value
    @property
    def kontakDokter(self):
        return self.__kontakDokter
        
    @kontakDokter.setter
    def kontakDokter(self, value):
        self.__kontakDokter = value
    def get_all(self):
        payload ={}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(self.__url, json=payload, headers=headers)
        return response.text
    def get_by_kodeDokter(self, kodeDokter):
        url = self.__url+"?kodeDokter="+kodeDokter
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, json=payload, headers=headers)
        data = json.loads(response.text)
        for item in data:
            self.__id = item['idDokter']
            self.__kodeDokter = item['kodeDokter']
            self.__nama = item['nama']
            self.__spesialis = item['spesialis']
            self.__kontakDokter = item['kontakDokter']
        return data
    def simpan(self):
        payload = {
            "kodeDokter":self.__kodeDokter,
            "nama":self.__nama,
            "spesialis":self.__spesialis,
            "kontakDokter":self.__kontakDokter
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.post(self.__url, data=payload, headers=headers)
        return response.text
    def update_by_kodeDokter(self, kodeDokter):
        url = self.__url+"?kodeDokter="+kodeDokter
        payload = {
            "kodeDokter":self.__kodeDokter,
            "nama":self.__nama,
            "spesialis":self.__spesialis,
            "kontakDokter":self.__kontakDokter
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.put(url, data=payload, headers=headers)
        return response.text
    def delete_by_kodeDokter(self,kodeDokter):
        url = self.__url+"?kodeDokter="+kodeDokter
        headers = {'Content-Type': 'application/json'}
        payload={}
        response = requests.delete(url, json=payload, headers=headers)
        return response.text