import tkinter as tk
import json
from tkinter import Frame,Label,Entry,Button,Radiobutton,ttk,VERTICAL,YES,BOTH,END,Tk,W,StringVar,messagebox
from Dokter import *
class FrmDokter:
    
    def __init__(self, parent, title):
        self.parent = parent       
        self.parent.geometry("500x450")
        self.parent.title(title)
        self.parent.protocol("WM_DELETE_WINDOW", self.onKeluar)
        self.ditemukan = None
        self.aturKomponen()
        self.onReload()
        
    def aturKomponen(self):
        mainFrame = Frame(self.parent, bd=10)
        mainFrame.pack(fill=BOTH, expand=YES)
        title_label = Label(mainFrame,
        text="01:Dokter Umum\n02:Dokter Mata\n03:Dokter THT\n04:Dokter Kandungan & Kebidanan\n05:Psikolog Klinis\n06:Dokter Gigi\n07:Dokter Sp. Penyakit Dalam",
        font=('','7'))
        title_label.place(x=330, y=5)
        Label(mainFrame, text='Kode Dokter:').grid(row=0, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='Nama Dokter:').grid(row=1, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='Spesialis:').grid(row=2, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='Kontak Dokter:').grid(row=3, column=0,
            sticky=W, padx=5, pady=5)

        # Textbox
        self.txtKodeDokter = Entry(mainFrame) 
        self.txtKodeDokter.grid(row=0, column=1, padx=5, pady=5)
        self.txtKodeDokter.bind("<Return>",self.onCari) # menambahkan event Enter key
        # Textbox
        self.txtNama = Entry(mainFrame) 
        self.txtNama.grid(row=1, column=1, padx=5, pady=5)
        # Textbox
        self.txtSpesialis = Entry(mainFrame) 
        self.txtSpesialis.grid(row=2, column=1, padx=5, pady=5)
        # Textbox
        self.txtKontakDokter = Entry(mainFrame) 
        self.txtKontakDokter.grid(row=3, column=1, padx=5, pady=5)
        # Button
        self.btnSimpan = Button(mainFrame, text='Simpan', command=self.onSimpan, width=10)
        self.btnSimpan.grid(row=0, column=3, padx=5, pady=5)
        self.btnClear = Button(mainFrame, text='Clear', command=self.onClear, width=10)
        self.btnClear.grid(row=1, column=3, padx=5, pady=5)
        self.btnHapus = Button(mainFrame, text='Hapus', command=self.onDelete, width=10)
        self.btnHapus.grid(row=2, column=3, padx=5, pady=5)
        # define columns
        columns = ('kodeDokter','nama','spesialis','kontakDokter')
        self.tree = ttk.Treeview(mainFrame, columns=columns, show='headings')
        # define headings
        self.tree.heading('kodeDokter', text='Kode Dokter')
        self.tree.column('kodeDokter', width="90")
        self.tree.heading('nama', text='Nama')
        self.tree.column('nama', width="110")
        self.tree.heading('spesialis', text='Spesialis')
        self.tree.column('spesialis', width="150")
        self.tree.heading('kontakDokter', text='Kontak')
        self.tree.column('kontakDokter', width="90")
        # set tree position
        self.tree.place(x=0, y=175)
        
    def onClear(self, event=None):
        self.txtKodeDokter.delete(0,END)
        self.txtKodeDokter.insert(END,"")
        self.txtNama.delete(0,END)
        self.txtNama.insert(END,"")
        self.txtSpesialis.delete(0,END)
        self.txtSpesialis.insert(END,"")
        self.txtKontakDokter.delete(0,END)
        self.txtKontakDokter.insert(END,"")
        self.btnSimpan.config(text="Simpan")
        self.onReload()
        self.ditemukan = False
        
    def onReload(self, event=None):
        # get data dokter
        obj = Dokter()
        result = obj.get_all()
        parsed_data = json.loads(result)
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        for i, d in enumerate(parsed_data):
            self.tree.insert("", i, text="Item {}".format(i), values=(d["kodeDokter"],d["nama"],d["spesialis"],d["kontakDokter"]))
    def onCari(self, event=None):
        kodeDokter = self.txtKodeDokter.get()
        obj = Dokter()
        a = obj.get_by_kodeDokter(kodeDokter)
        if(len(a)>0):
            self.TampilkanData()
            self.ditemukan = True
        else:
            self.ditemukan = False
            messagebox.showinfo("showinfo", "Data Tidak Ditemukan")
    def TampilkanData(self, event=None):
        kodeDokter = self.txtKodeDokter.get()
        obj = Dokter()
        res = obj.get_by_kodeDokter(kodeDokter)
        self.txtKodeDokter.delete(0,END)
        self.txtKodeDokter.insert(END,obj.kodeDokter)
        self.txtNama.delete(0,END)
        self.txtNama.insert(END,obj.nama)
        self.txtSpesialis.delete(0,END)
        self.txtSpesialis.insert(END,obj.spesialis)
        self.txtKontakDokter.delete(0,END)
        self.txtKontakDokter.insert(END,obj.kontakDokter)
        self.btnSimpan.config(text="Update")
                 
    def onSimpan(self, event=None):
        # get the data from input
        kodeDokter = self.txtKodeDokter.get()
        nama = self.txtNama.get()
        spesialis = self.txtSpesialis.get()
        kontakDokter = self.txtKontakDokter.get()
        # create new Object
        obj = Dokter()
        obj.kodeDokter = kodeDokter
        obj.nama = nama
        obj.spesialis = spesialis
        obj.kontakDokter = kontakDokter
        if(self.ditemukan==False):
            # save the record
            res = obj.simpan()
        else:
            # update the record
            res = obj.update_by_kodeDokter(kodeDokter)
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        #clear the form input
        self.onClear()
    def onDelete(self, event=None):
        kodeDokter = self.txtKodeDokter.get()
        obj = Dokter()
        obj.kodeDokter = kodeDokter
        if(self.ditemukan==True):
            res = obj.delete_by_kodeDokter(kodeDokter)
        else:
            messagebox.showinfo("showinfo", "Data harus ditemukan dulu sebelum dihapus")
            
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        
        self.onClear()
            
    def onKeluar(self, event=None):
        # memberikan perintah menutup aplikasi
        self.parent.destroy()
if __name__ == '__main__':
    root2 = tk.Tk()
    aplikasi = FrmDokter(root2, "Aplikasi Data Dokter")
    root2.mainloop()
