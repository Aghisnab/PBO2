import requests
import json
class Kunjungan:
    def __init__(self):
        self.__id=None
        self.__kodeKunjungan = None
        self.__kodePasien = None
        self.__kodeDokter = None
        self.__tglKunjungan = None
        self.__keluhan = None
        self.__url = "http://f0832659.xsph.ru/apprawatjalan/kunjungan_api.php"
                    
    @property
    def id(self):
        return self.__id
    @property
    def kodeKunjungan(self):
        return self.__kodeKunjungan
        
    @kodeKunjungan.setter
    def kodeKunjungan(self, value):
        self.__kodeKunjungan = value
    @property
    def kodePasien(self):
        return self.__kodePasien
        
    @kodePasien.setter
    def kodePasien(self, value):
        self.__kodePasien = value
    @property
    def kodeDokter(self):
        return self.__kodeDokter
        
    @kodeDokter.setter
    def kodeDokter(self, value):
        self.__kodeDokter = value
    @property
    def tglKunjungan(self):
        return self.__tglKunjungan
        
    @tglKunjungan.setter
    def tglKunjungan(self, value):
        self.__tglKunjungan = value
    @property
    def keluhan(self):
        return self.__keluhan
        
    @keluhan.setter
    def keluhan(self, value):
        self.__keluhan = value
    def get_all(self):
        payload ={}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(self.__url, json=payload, headers=headers)
        return response.text
    def get_by_kodeKunjungan(self, kodeKunjungan):
        url = self.__url+"?kodeKunjungan="+kodeKunjungan
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, json=payload, headers=headers)
        data = json.loads(response.text)
        for item in data:
            self.__id = item['idKunjungan']
            self.__kodeKunjungan = item['kodeKunjungan']
            self.__kodePasien = item['kodePasien']
            self.__kodeDokter = item['kodeDokter']
            self.__tglKunjungan = item['tglKunjungan']
            self.__keluhan = item['keluhan']
        return data
    def simpan(self):
        payload = {
            "kodeKunjungan":self.__kodeKunjungan,
            "kodePasien":self.__kodePasien,
            "kodeDokter":self.__kodeDokter,
            "tglKunjungan":self.__tglKunjungan,
            "keluhan":self.__keluhan
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.post(self.__url, data=payload, headers=headers)
        return response.text
    def update_by_kodeKunjungan(self, kodeKunjungan):
        url = self.__url+"?kodeKunjungan="+kodeKunjungan
        payload = {
            "kodeKunjungan":self.__kodeKunjungan,
            "kodePasien":self.__kodePasien,
            "kodeDokter":self.__kodeDokter,
            "tglKunjungan":self.__tglKunjungan,
            "keluhan":self.__keluhan
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.put(url, data=payload, headers=headers)
        return response.text
    def delete_by_kodeKunjungan(self,kodeKunjungan):
        url = self.__url+"?kodeKunjungan="+kodeKunjungan
        headers = {'Content-Type': 'application/json'}
        payload={}
        response = requests.delete(url, json=payload, headers=headers)
        return response.text