import requests
import json
class Pasien:
    def __init__(self):
        self.__id=None
        self.__kodePasien = None
        self.__namaPasien = None
        self.__jk = None
        self.__tglLahir = None
        self.__kontak = None
        self.__url = "http://f0832659.xsph.ru/apprawatjalan/pasien_api.php"
                    
    @property
    def id(self):
        return self.__id
    @property
    def kodePasien(self):
        return self.__kodePasien
        
    @kodePasien.setter
    def kodePasien(self, value):
        self.__kodePasien = value
    @property
    def namaPasien(self):
        return self.__namaPasien
        
    @namaPasien.setter
    def namaPasien(self, value):
        self.__namaPasien = value
    @property
    def jk(self):
        return self.__jk
        
    @jk.setter
    def jk(self, value):
        self.__jk = value
    @property
    def tglLahir(self):
        return self.__tglLahir
        
    @tglLahir.setter
    def tglLahir(self, value):
        self.__tglLahir = value
    @property
    def kontak(self):
        return self.__kontak
        
    @kontak.setter
    def kontak(self, value):
        self.__kontak = value
    def get_all(self):
        payload ={}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(self.__url, json=payload, headers=headers)
        return response.text
    def get_by_kodePasien(self, kodePasien):
        url = self.__url+"?kodePasien="+kodePasien
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, json=payload, headers=headers)
        data = json.loads(response.text)
        for item in data:
            self.__id = item['idPasien']
            self.__kodePasien = item['kodePasien']
            self.__namaPasien = item['namaPasien']
            self.__jk = item['jk']
            self.__tglLahir = item['tglLahir']
            self.__kontak = item['kontak']
        return data
    def simpan(self):
        payload = {
            "kodePasien":self.__kodePasien,
            "namaPasien":self.__namaPasien,
            "jk":self.__jk,
            "tglLahir":self.__tglLahir,
            "kontak":self.__kontak
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.post(self.__url, data=payload, headers=headers)
        return response.text
    def update_by_kodePasien(self, kodePasien):
        url = self.__url+"?kodePasien="+kodePasien
        payload = {
            "kodePasien":self.__kodePasien,
            "namaPasien":self.__namaPasien,
            "jk":self.__jk,
            "tglLahir":self.__tglLahir,
            "kontak":self.__kontak
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.put(url, data=payload, headers=headers)
        return response.text
    def delete_by_kodePasien(self,kodePasien):
        url = self.__url+"?kodePasien="+kodePasien
        headers = {'Content-Type': 'application/json'}
        payload={}
        response = requests.delete(url, json=payload, headers=headers)
        return response.text