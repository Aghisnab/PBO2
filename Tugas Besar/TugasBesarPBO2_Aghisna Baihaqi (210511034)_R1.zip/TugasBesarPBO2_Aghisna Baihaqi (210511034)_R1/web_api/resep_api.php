<?php
require_once 'database.php';
require_once 'Resep.php';
$db = new MySQLDatabase();
$resep = new Resep($db);
$id=0;
$kodeResep=0;
// Check the HTTP request method
$method = $_SERVER['REQUEST_METHOD'];
// Handle the different HTTP methods
switch ($method) {
    case 'GET':
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['kodeResep'])){
            $kodeResep = $_GET['kodeResep'];
        }
        if($id>0){    
            $result = $resep->get_by_id($id);
        }elseif($kodeResep>0){
            $result = $resep->get_by_kodeResep($kodeResep);
        } else {
            $result = $resep->get_all();
        }        
       
        $val = array();
        while ($row = $result->fetch_assoc()) {
            $val[] = $row;
        }
        
        header('Content-Type: application/json');
        echo json_encode($val);
        break;
    
    case 'POST':
        // Add a new resep
        $resep->kodeResep = $_POST['kodeResep'];
        $resep->kodeKunjungan = $_POST['kodeKunjungan'];
        $resep->obat = $_POST['obat'];
        $resep->dosis = $_POST['dosis'];
        $resep->instruksi = $_POST['instruksi'];
       
        $resep->insert();
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Resep created successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Resep not created.';
        }
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    case 'PUT':
        // Update an existing data
        $_PUT = [];
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['kodeResep'])){
            $kodeResep = $_GET['kodeResep'];
        }
        parse_str(file_get_contents("php://input"), $_PUT);
        $resep->kodeResep = $_PUT['kodeResep'];
        $resep->kodeKunjungan = $_PUT['kodeKunjungan'];
        $resep->obat = $_PUT['obat'];
        $resep->dosis = $_PUT['dosis'];
        $resep->instruksi = $_PUT['instruksi'];
        if($id>0){    
            $resep->update($id);
        }elseif($kodeResep<>""){
            $resep->update_by_kodeResep($kodeResep);
        } else {
            
        } 
        
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Resep updated successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Resep update failed.';
        }        
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    case 'DELETE':
        // Delete a user
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['kodeResep'])){
            $kodeResep = $_GET['kodeResep'];
        }
        if($id>0){    
            $resep->delete($id);
        }elseif($kodeResep>0){
            $resep->delete_by_kodeResep($kodeResep);
        } else {
            
        } 
        
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Resep deleted successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Resep delete failed.';
        }        
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    default:
        header("HTTP/1.0 405 Method Not Allowed");
        break;
    }
$db->close()
?>