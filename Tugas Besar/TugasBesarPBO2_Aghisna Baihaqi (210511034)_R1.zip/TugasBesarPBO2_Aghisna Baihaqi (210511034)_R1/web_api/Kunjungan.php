<?php
//Simpanlah dengan nama file : Kunjungan.php
require_once 'database.php';
class Kunjungan 
{
    private $db;
    private $table = 'kunjungan';
    public $kodeKunjungan = "";
    public $kodePasien = "";
    public $kodeDokter = "";
    public $tglKunjungan = "";
    public $keluhan = "";
    public function __construct(MySQLDatabase $db)
    {
        $this->db = $db;
    }
    public function get_all() 
    {
        $query = "SELECT * FROM $this->table";
        $result_set = $this->db->query($query);
        return $result_set;
    }
    public function get_by_id(int $id)
    {
        $query = "SELECT * FROM $this->table WHERE id = $id";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function get_by_kodeKunjungan(string $kodeKunjungan)
    {
        $query = "SELECT * FROM $this->table WHERE kodeKunjungan = $kodeKunjungan";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function insert(): int
    {
        $query = "INSERT INTO $this->table (`kodeKunjungan`,`kodePasien`,`kodeDokter`,`tglKunjungan`,`keluhan`) VALUES ('$this->kodeKunjungan','$this->kodePasien','$this->kodeDokter','$this->tglKunjungan','$this->keluhan')";
        $this->db->query($query);
        return $this->db->insert_id();
    }
    public function update(int $id): int
    {
        $query = "UPDATE $this->table SET kodeKunjungan = '$this->kodeKunjungan', kodePasien = '$this->kodePasien', kodeDokter = '$this->kodeDokter', tglKunjungan = '$this->tglKunjungan', keluhan = '$this->keluhan' 
        WHERE idKunjungan = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function update_by_kodeKunjungan($kodeKunjungan): int
    {
        $query = "UPDATE $this->table SET kodeKunjungan = '$this->kodeKunjungan', kodePasien = '$this->kodePasien', kodeDokter = '$this->kodeDokter', tglKunjungan = '$this->tglKunjungan', keluhan = '$this->keluhan' 
        WHERE kodeKunjungan = $kodeKunjungan";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete(int $id): int
    {
        $query = "DELETE FROM $this->table WHERE idKunjungan = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete_by_kodeKunjungan($kodeKunjungan): int
    {
        $query = "DELETE FROM $this->table WHERE kodeKunjungan = $kodeKunjungan";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
}
?>