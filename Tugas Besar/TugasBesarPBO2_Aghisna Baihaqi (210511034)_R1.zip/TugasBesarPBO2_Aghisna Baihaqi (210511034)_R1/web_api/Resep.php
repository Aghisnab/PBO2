<?php
//Simpanlah dengan nama file : Resep.php
require_once 'database.php';
class Resep 
{
    private $db;
    private $table = 'resep';
    public $kodeResep = "";
    public $kodeKunjungan = "";
    public $obat = "";
    public $dosis = "";
    public $instruksi = "";
    public function __construct(MySQLDatabase $db)
    {
        $this->db = $db;
    }
    public function get_all() 
    {
        $query = "SELECT * FROM $this->table";
        $result_set = $this->db->query($query);
        return $result_set;
    }
    public function get_by_id(int $id)
    {
        $query = "SELECT * FROM $this->table WHERE id = $id";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function get_by_kodeResep(string $kodeResep)
    {
        $query = "SELECT * FROM $this->table WHERE kodeResep = $kodeResep";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function insert(): int
    {
        $query = "INSERT INTO $this->table (`kodeResep`,`kodeKunjungan`,`obat`,`dosis`,`instruksi`) VALUES ('$this->kodeResep','$this->kodeKunjungan','$this->obat','$this->dosis','$this->instruksi')";
        $this->db->query($query);
        return $this->db->insert_id();
    }
    public function update(int $id): int
    {
        $query = "UPDATE $this->table SET kodeResep = '$this->kodeResep', kodeKunjungan = '$this->kodeKunjungan', obat = '$this->obat', dosis = '$this->dosis', instruksi = '$this->instruksi' 
        WHERE idResep = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function update_by_kodeResep($kodeResep): int
    {
        $query = "UPDATE $this->table SET kodeResep = '$this->kodeResep', kodeKunjungan = '$this->kodeKunjungan', obat = '$this->obat', dosis = '$this->dosis', instruksi = '$this->instruksi' 
        WHERE kodeResep = $kodeResep";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete(int $id): int
    {
        $query = "DELETE FROM $this->table WHERE idResep = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete_by_kodeResep($kodeResep): int
    {
        $query = "DELETE FROM $this->table WHERE kodeResep = $kodeResep";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
}
?>