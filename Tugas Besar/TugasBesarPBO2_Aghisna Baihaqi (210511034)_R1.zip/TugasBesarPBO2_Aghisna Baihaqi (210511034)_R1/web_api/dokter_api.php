<?php
require_once 'database.php';
require_once 'Dokter.php';
$db = new MySQLDatabase();
$dokter = new Dokter($db);
$id=0;
$kodeDokter=0;
// Check the HTTP request method
$method = $_SERVER['REQUEST_METHOD'];
// Handle the different HTTP methods
switch ($method) {
    case 'GET':
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['kodeDokter'])){
            $kodeDokter = $_GET['kodeDokter'];
        }
        if($id>0){    
            $result = $dokter->get_by_id($id);
        }elseif($kodeDokter>0){
            $result = $dokter->get_by_kodeDokter($kodeDokter);
        } else {
            $result = $dokter->get_all();
        }        
       
        $val = array();
        while ($row = $result->fetch_assoc()) {
            $val[] = $row;
        }
        
        header('Content-Type: application/json');
        echo json_encode($val);
        break;
    
    case 'POST':
        // Add a new dokter
        $dokter->kodeDokter = $_POST['kodeDokter'];
        $dokter->nama = $_POST['nama'];
        $dokter->spesialis = $_POST['spesialis'];
        $dokter->kontakDokter = $_POST['kontakDokter'];
       
        $dokter->insert();
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Dokter created successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Dokter not created.';
        }
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    case 'PUT':
        // Update an existing data
        $_PUT = [];
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['kodeDokter'])){
            $kodeDokter = $_GET['kodeDokter'];
        }
        parse_str(file_get_contents("php://input"), $_PUT);
        $dokter->kodeDokter = $_PUT['kodeDokter'];
        $dokter->nama = $_PUT['nama'];
        $dokter->spesialis = $_PUT['spesialis'];
        $dokter->kontakDokter = $_PUT['kontakDokter'];
        if($id>0){    
            $dokter->update($id);
        }elseif($kodeDokter<>""){
            $dokter->update_by_kodeDokter($kodeDokter);
        } else {
            
        } 
        
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Dokter updated successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Dokter update failed.';
        }        
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    case 'DELETE':
        // Delete a user
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['kodeDokter'])){
            $kodeDokter = $_GET['kodeDokter'];
        }
        if($id>0){    
            $dokter->delete($id);
        }elseif($kodeDokter>0){
            $dokter->delete_by_kodeDokter($kodeDokter);
        } else {
            
        } 
        
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Dokter deleted successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Dokter delete failed.';
        }        
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    default:
        header("HTTP/1.0 405 Method Not Allowed");
        break;
    }
$db->close()
?>