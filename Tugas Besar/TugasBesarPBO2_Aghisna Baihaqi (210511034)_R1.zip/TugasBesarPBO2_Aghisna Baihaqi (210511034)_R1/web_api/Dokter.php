<?php
//Simpanlah dengan nama file : Dokter.php
require_once 'database.php';
class Dokter 
{
    private $db;
    private $table = 'dokter';
    public $kodeDokter = "";
    public $nama = "";
    public $spesialis = "";
    public $kontakDokter = "";
    public function __construct(MySQLDatabase $db)
    {
        $this->db = $db;
    }
    public function get_all() 
    {
        $query = "SELECT * FROM $this->table";
        $result_set = $this->db->query($query);
        return $result_set;
    }
    public function get_by_id(int $id)
    {
        $query = "SELECT * FROM $this->table WHERE id = $id";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function get_by_kodeDokter(string $kodeDokter)
    {
        $query = "SELECT * FROM $this->table WHERE kodeDokter = $kodeDokter";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function insert(): int
    {
        $query = "INSERT INTO $this->table (`kodeDokter`,`nama`,`spesialis`,`kontakDokter`) VALUES ('$this->kodeDokter','$this->nama','$this->spesialis','$this->kontakDokter')";
        $this->db->query($query);
        return $this->db->insert_id();
    }
    public function update(int $id): int
    {
        $query = "UPDATE $this->table SET kodeDokter = '$this->kodeDokter', nama = '$this->nama', spesialis = '$this->spesialis', kontakDokter = '$this->kontakDokter' 
        WHERE idDokter = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function update_by_kodeDokter($kodeDokter): int
    {
        $query = "UPDATE $this->table SET kodeDokter = '$this->kodeDokter', nama = '$this->nama', spesialis = '$this->spesialis', kontakDokter = '$this->kontakDokter' 
        WHERE kodeDokter = $kodeDokter";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete(int $id): int
    {
        $query = "DELETE FROM $this->table WHERE idDokter = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete_by_kodeDokter($kodeDokter): int
    {
        $query = "DELETE FROM $this->table WHERE kodeDokter = $kodeDokter";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
}
?>